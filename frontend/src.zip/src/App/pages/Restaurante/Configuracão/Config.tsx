import React, { useRef, useState } from 'react';
import RestaurantLayout from '../../../../shared/components/layout/Restaurantelayout';
import './Config.css';

// ── Tipos ──────────────────────────────────────────────────────────────────────
interface HorarioFuncionamento {
  diaSemana: string;
  abertura: string;
  fechamento: string;
}

interface ConfiguracaoRestaurante {
  nome: string;
  foto: string | null;
  endereco: string;
  bairro: string;
  cep: string;
  cidade: string;
  estado: string;
  horario: HorarioFuncionamento;
}

// ── Dados iniciais mockados (substituir por API futuramente) ───────────────────
const DIAS_SEMANA = [
  'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo',
];

const HORARIOS = Array.from({ length: 24 }, (_, i) => {
  const hora = String(i).padStart(2, '0');
  return `${hora}:00`;
});

const ESTADOS_BR = [
  'AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA',
  'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN',
  'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO',
];

const CONFIG_INICIAL: ConfiguracaoRestaurante = {
  nome: 'Bistrô Sabor & Cia',
  foto: null,
  endereco: 'Rua das Flores, 123',
  bairro: 'Centro',
  cep: '01234-567',
  cidade: 'São Paulo',
  estado: 'SP',
  horario: { diaSemana: 'Segunda', abertura: '18:00', fechamento: '23:00' },
};

// ── Componente ─────────────────────────────────────────────────────────────────
const Config: React.FC = () => {
  const [config, setConfig] = useState<ConfiguracaoRestaurante>(CONFIG_INICIAL);
  const [previewFoto, setPreviewFoto] = useState<string | null>(null);
  const [salvando, setSalvando] = useState(false);
  const [salvoComSucesso, setSalvoComSucesso] = useState(false);
  const inputFotoRef = useRef<HTMLInputElement>(null);

  // ── Handlers genéricos ──────────────────────────────────────────────────────
  const handleCampo = (campo: keyof ConfiguracaoRestaurante, valor: string) => {
    setConfig((prev) => ({ ...prev, [campo]: valor }));
  };

  const handleHorario = (campo: keyof HorarioFuncionamento, valor: string) => {
    setConfig((prev) => ({
      ...prev,
      horario: { ...prev.horario, [campo]: valor },
    }));
  };

  // ── Upload de foto ──────────────────────────────────────────────────────────
  const handleAlterarFoto = () => {
    inputFotoRef.current?.click();
  };

  const handleFotoSelecionada = (e: React.ChangeEvent<HTMLInputElement>) => {
    const arquivo = e.target.files?.[0];
    if (!arquivo) return;

    const url = URL.createObjectURL(arquivo);
    setPreviewFoto(url);
  };

  // ── Salvar configurações ────────────────────────────────────────────────────
  const handleSalvar = async () => {
    setSalvando(true);

    // Simula chamada de API
    await new Promise((resolve) => setTimeout(resolve, 1000));

    setSalvando(false);
    setSalvoComSucesso(true);
    setTimeout(() => setSalvoComSucesso(false), 3000);
  };

  // ── Render ──────────────────────────────────────────────────────────────────
  return (
    <div className="config">
      <h1 className="config__titulo">Configurações</h1>

      {/* Seção: Informações do Restaurante */}
      <section className="config__secao">
        <h2 className="config__secao-titulo">Informações do Restaurante</h2>

        <div className="config__info-restaurante">
          {/* Avatar */}
          <div className="config__avatar-wrap">
            <img
              className="config__avatar"
              src={previewFoto ?? '/icons/restaurant-avatar.png'}
              alt="Foto do restaurante"
            />
          </div>

          {/* Nome */}
          <div className="config__campo-grupo">
            <label className="config__label" htmlFor="nomeRestaurante">
              Nome do Restaurante:
            </label>
            <div className="config__input-wrap">
              <input
                id="nomeRestaurante"
                className="config__input"
                type="text"
                value={config.nome}
                onChange={(e) => handleCampo('nome', e.target.value)}
                aria-describedby="nomeRestauranteHint"
              />
              <span className="config__input-icone">✏️</span>
            </div>
            <p id="nomeRestauranteHint" className="config__hint">
              Este nome será exibido para os seus clientes.
            </p>

            <button
              className="config__btn-filial"
              type="button"
              aria-label="Cadastrar filial"
            >
              🏪 Cadastrar Filial
            </button>
          </div>

          {/* Foto */}
          <div className="config__foto-wrap">
            <label className="config__label">Foto do Restaurante:</label>
            <button
              className="config__btn-foto"
              type="button"
              onClick={handleAlterarFoto}
              aria-label="Alterar foto do restaurante"
            >
              ⬆️ Alterar Foto
            </button>
            <p className="config__hint">
              Formato recomendado:<br />JPG ou PNG (máx. 5MB)
            </p>
            <input
              ref={inputFotoRef}
              type="file"
              accept="image/jpeg,image/png"
              className="config__input-arquivo"
              onChange={handleFotoSelecionada}
              aria-label="Selecionar arquivo de foto"
            />
          </div>
        </div>
      </section>

      {/* Seção: Endereço do Restaurante */}
      <section className="config__secao">
        <h2 className="config__secao-titulo">Endereço do Restaurante</h2>

        <div className="config__endereco-grid">
          <div className="config__campo config__campo--endereco">
            <label className="config__label" htmlFor="endereco">Endereço:</label>
            <input
              id="endereco"
              className="config__input"
              type="text"
              value={config.endereco}
              onChange={(e) => handleCampo('endereco', e.target.value)}
            />
          </div>

          <div className="config__campo config__campo--bairro">
            <label className="config__label" htmlFor="bairro">Bairro:</label>
            <input
              id="bairro"
              className="config__input"
              type="text"
              value={config.bairro}
              onChange={(e) => handleCampo('bairro', e.target.value)}
            />
          </div>

          <div className="config__campo config__campo--cep">
            <label className="config__label" htmlFor="cep">CEP:</label>
            <input
              id="cep"
              className="config__input"
              type="text"
              value={config.cep}
              maxLength={9}
              onChange={(e) => handleCampo('cep', e.target.value)}
            />
          </div>

          <div className="config__campo config__campo--cidade">
            <label className="config__label" htmlFor="cidade">Cidade:</label>
            <input
              id="cidade"
              className="config__input"
              type="text"
              value={config.cidade}
              onChange={(e) => handleCampo('cidade', e.target.value)}
            />
          </div>

          <div className="config__campo config__campo--estado">
            <label className="config__label" htmlFor="estado">Estado:</label>
            <select
              id="estado"
              className="config__select"
              value={config.estado}
              onChange={(e) => handleCampo('estado', e.target.value)}
            >
              {ESTADOS_BR.map((uf) => (
                <option key={uf} value={uf}>{uf}</option>
              ))}
            </select>
          </div>
        </div>
      </section>

      {/* Seção: Horários de Funcionamento */}
      <section className="config__secao">
        <h2 className="config__secao-titulo">Horários de Funcionamento</h2>

        <div className="config__horario-row">
          {/* Dia da semana */}
          <select
            className="config__select config__select--dia"
            value={config.horario.diaSemana}
            onChange={(e) => handleHorario('diaSemana', e.target.value)}
            aria-label="Dia da semana"
          >
            {DIAS_SEMANA.map((dia) => (
              <option key={dia} value={dia}>{dia}</option>
            ))}
          </select>

          {/* Abertura */}
          <select
            className="config__select config__select--hora"
            value={config.horario.abertura}
            onChange={(e) => handleHorario('abertura', e.target.value)}
            aria-label="Horário de abertura"
          >
            {HORARIOS.map((h) => (
              <option key={h} value={h}>{h}</option>
            ))}
          </select>

          <span className="config__horario-ate">até</span>

          {/* Fechamento */}
          <select
            className="config__select config__select--hora"
            value={config.horario.fechamento}
            onChange={(e) => handleHorario('fechamento', e.target.value)}
            aria-label="Horário de fechamento"
          >
            {HORARIOS.map((h) => (
              <option key={h} value={h}>{h}</option>
            ))}
          </select>

          <button
            className="config__btn-checar"
            type="button"
            aria-label="Checar horário geral"
          >
            Checar horario geral
          </button>
        </div>
      </section>

      {/* Feedback de sucesso */}
      {salvoComSucesso && (
        <div className="config__feedback-sucesso" role="status">
          ✅ Configurações salvas com sucesso!
        </div>
      )}

      {/* Botão salvar */}
      <button
        className="config__btn-salvar"
        type="button"
        onClick={handleSalvar}
        disabled={salvando}
        aria-label="Salvar configurações"
      >
        {salvando ? '⏳ Salvando...' : '💾 Salvar Configurações'}
      </button>
    </div>
  );
};

export default Config;